##### **ÁRBOL AVL**



digraph G {

&#x20;   node \[shape=record, style=filled, fillcolor=lightblue];

&#x20;   label="Arbol AVL de Productos (por Nombre)";

&#x20;   "node0x231523a1d60" \[label="{Nombre: Leche Entera 1L | FE: 0}"];

&#x20;   "node0x231523a1d60" -> "node0x231523ad4f0" \[label="L"];

&#x20;   "node0x231523ad4f0" \[label="{Nombre: Detergente Polvo | FE: 0}"];

&#x20;   "node0x231523ad4f0" -> "node0x231523aa320" \[label="L"];

&#x20;   "node0x231523aa320" \[label="{Nombre: Cafe Soluble | FE: 0}"];

&#x20;   "node0x231523aa320" -> "node0x231523c7370" \[label="L"];

&#x20;   "node0x231523c7370" \[label="{Nombre: Arroz Blanco 1kg | FE: 0}"];

&#x20;   "node0x231523c7370" -> "node0x231523c7f30" \[label="L"];

&#x20;   "node0x231523c7f30" \[label="{Nombre: Aceite Vegetal | FE: -1}"];

&#x20;   "node0x231523c7f30" -> "node0x231523a9ff0" \[label="R"];

&#x20;   "node0x231523a9ff0" \[label="{Nombre: Agua Mineral 600ml | FE: 0}"];

&#x20;   "node0x231523c7370" -> "node0x231523aa2f0" \[label="R"];

&#x20;   "node0x231523aa2f0" \[label="{Nombre: Azucar Blanca | FE: 0}"];

&#x20;   "node0x231523aa2f0" -> "node0x231523aa0b0" \[label="L"];

&#x20;   "node0x231523aa0b0" \[label="{Nombre: Atun en Agua | FE: 0}"];

&#x20;   "node0x231523aa2f0" -> "node0x231523ad640" \[label="R"];

&#x20;   "node0x231523ad640" \[label="{Nombre: Cacahuates Salados | FE: 0}"];

&#x20;   "node0x231523aa320" -> "node0x231523ad400" \[label="R"];

&#x20;   "node0x231523ad400" \[label="{Nombre: Cloro 1L | FE: 0}"];

&#x20;   "node0x231523ad400" -> "node0x231523aa260" \[label="L"];

&#x20;   "node0x231523aa260" \[label="{Nombre: Cereal de Maiz | FE: -1}"];

&#x20;   "node0x231523aa260" -> "node0x231523ad460" \[label="R"];

&#x20;   "node0x231523ad460" \[label="{Nombre: Chocolate Barra | FE: 0}"];

&#x20;   "node0x231523ad400" -> "node0x231523ad130" \[label="R"];

&#x20;   "node0x231523ad130" \[label="{Nombre: Desodorante Spray | FE: 1}"];

&#x20;   "node0x231523ad130" -> "node0x231523ad2e0" \[label="L"];

&#x20;   "node0x231523ad2e0" \[label="{Nombre: Crema Corporal | FE: 0}"];

&#x20;   "node0x231523ad4f0" -> "node0x231523aa200" \[label="R"];

&#x20;   "node0x231523aa200" \[label="{Nombre: Harina de Trigo | FE: -1}"];

&#x20;   "node0x231523aa200" -> "node0x231523aa350" \[label="L"];

&#x20;   "node0x231523aa350" \[label="{Nombre: Galletas Maria | FE: 0}"];

&#x20;   "node0x231523aa350" -> "node0x231523c7cc0" \[label="L"];

&#x20;   "node0x231523c7cc0" \[label="{Nombre: Frijol Negro 1kg | FE: 0}"];

&#x20;   "node0x231523aa350" -> "node0x231523ad490" \[label="R"];

&#x20;   "node0x231523ad490" \[label="{Nombre: Gomitas Frutas | FE: 0}"];

&#x20;   "node0x231523aa200" -> "node0x231523ad010" \[label="R"];

&#x20;   "node0x231523ad010" \[label="{Nombre: Jabon Liquido Manos | FE: 0}"];

&#x20;   "node0x231523ad010" -> "node0x231523ad160" \[label="L"];

&#x20;   "node0x231523ad160" \[label="{Nombre: Helado Vainilla | FE: -1}"];

&#x20;   "node0x231523ad160" -> "node0x231523ca780" \[label="R"];

&#x20;   "node0x231523ca780" \[label="{Nombre: Huevo Blanco 12pzs | FE: 0}"];

&#x20;   "node0x231523ad010" -> "node0x231523aa2c0" \[label="R"];

&#x20;   "node0x231523aa2c0" \[label="{Nombre: Jugo de Naranja | FE: 0}"];

&#x20;   "node0x231523aa2c0" -> "node0x231523ad2b0" \[label="L"];

&#x20;   "node0x231523ad2b0" \[label="{Nombre: Jabon de Barra | FE: 0}"];

&#x20;   "node0x231523aa2c0" -> "node0x231523ad670" \[label="R"];

&#x20;   "node0x231523ad670" \[label="{Nombre: Ketchup 380g | FE: 0}"];

&#x20;   "node0x231523a1d60" -> "node0x231523a1f10" \[label="R"];

&#x20;   "node0x231523a1f10" \[label="{Nombre: Pasta Spaguetti | FE: 0}"];

&#x20;   "node0x231523a1f10" -> "node0x231523aa080" \[label="L"];

&#x20;   "node0x231523aa080" \[label="{Nombre: Mermelada Fresa | FE: 0}"];

&#x20;   "node0x231523aa080" -> "node0x231523ad520" \[label="L"];

&#x20;   "node0x231523ad520" \[label="{Nombre: Limpiador Multiusos | FE: -1}"];

&#x20;   "node0x231523ad520" -> "node0x231523aa1d0" \[label="L"];

&#x20;   "node0x231523aa1d0" \[label="{Nombre: Lentejas 500g | FE: 0}"];

&#x20;   "node0x231523ad520" -> "node0x231523aa290" \[label="R"];

&#x20;   "node0x231523aa290" \[label="{Nombre: Mayonesa 400g | FE: 1}"];

&#x20;   "node0x231523aa290" -> "node0x231523ad040" \[label="L"];

&#x20;   "node0x231523ad040" \[label="{Nombre: Mantequilla 90g | FE: 0}"];

&#x20;   "node0x231523aa080" -> "node0x231523aa020" \[label="R"];

&#x20;   "node0x231523aa020" \[label="{Nombre: Pan de Caja | FE: 0}"];

&#x20;   "node0x231523aa020" -> "node0x231523ad100" \[label="L"];

&#x20;   "node0x231523ad100" \[label="{Nombre: Mostaza 200g | FE: -1}"];

&#x20;   "node0x231523ad100" -> "node0x231523ad370" \[label="R"];

&#x20;   "node0x231523ad370" \[label="{Nombre: Nachos 150g | FE: 0}"];

&#x20;   "node0x231523aa020" -> "node0x231523ad0d0" \[label="R"];

&#x20;   "node0x231523ad0d0" \[label="{Nombre: Papel Higienico 4pzs | FE: 1}"];

&#x20;   "node0x231523ad0d0" -> "node0x231523ad340" \[label="L"];

&#x20;   "node0x231523ad340" \[label="{Nombre: Papas Fritas 100g | FE: 0}"];

&#x20;   "node0x231523a1f10" -> "node0x231523ad190" \[label="R"];

&#x20;   "node0x231523ad190" \[label="{Nombre: Suavizante Telas | FE: 1}"];

&#x20;   "node0x231523ad190" -> "node0x231523aa0e0" \[label="L"];

&#x20;   "node0x231523aa0e0" \[label="{Nombre: Sal de Mesa | FE: 0}"];

&#x20;   "node0x231523aa0e0" -> "node0x231523ad280" \[label="L"];

&#x20;   "node0x231523ad280" \[label="{Nombre: Pizza Congelada | FE: 0}"];

&#x20;   "node0x231523ad280" -> "node0x231523ad580" \[label="L"];

&#x20;   "node0x231523ad580" \[label="{Nombre: Pasta de Dientes | FE: 0}"];

&#x20;   "node0x231523ad280" -> "node0x231523aa050" \[label="R"];

&#x20;   "node0x231523aa050" \[label="{Nombre: Refresco de Cola | FE: 0}"];

&#x20;   "node0x231523aa0e0" -> "node0x231523acf80" \[label="R"];

&#x20;   "node0x231523acf80" \[label="{Nombre: Servilletas 100pzs | FE: 0}"];

&#x20;   "node0x231523acf80" -> "node0x231523aa1a0" \[label="L"];

&#x20;   "node0x231523aa1a0" \[label="{Nombre: Sardinas Tomate | FE: 0}"];

&#x20;   "node0x231523acf80" -> "node0x231523ad550" \[label="R"];

&#x20;   "node0x231523ad550" \[label="{Nombre: Shampoo 400ml | FE: 0}"];

&#x20;   "node0x231523ad190" -> "node0x231523ad6d0" \[label="R"];

&#x20;   "node0x231523ad6d0" \[label="{Nombre: Verduras Mixtas | FE: 0}"];

&#x20;   "node0x231523ad6d0" -> "node0x231523ad1f0" \[label="L"];

&#x20;   "node0x231523ad1f0" \[label="{Nombre: Suavizante Telas | FE: 0}"];

&#x20;   "node0x231523ad6d0" -> "node0x231523c7180" \[label="R"];

&#x20;   "node0x231523c7180" \[label="{Nombre: Yogurt Fresa | FE: 0}"];

}





##### **ÁRBOL B**



digraph G {

&#x20; node \[shape=record, height=.1, style=filled, fillcolor=lemonchiffon];

&#x20; label="Estructura Arbol B (Orden 5) - Filtro por Fecha";

&#x20; "node0x231523abd20" \[label="<f0> | 2026-12-31 | <f1> | 2027-05-14 | <f2> | 2028-01-20 | <f3>"];

&#x20; "node0x231523abd20":f0 -> "node0x231523c7db0";

&#x20; "node0x231523c7db0" \[label="<f0> | 2026-05-15 | <f1> | 2026-07-20 | <f2> | 2026-09-30 | <f3>"];

&#x20; "node0x231523c7db0":f0 -> "node0x231523a1d90";

&#x20; "node0x231523a1d90" \[label="<f0> | 2026-04-01 | <f1> | 2026-04-10 | <f2> | 2026-04-10 | <f3>"];

&#x20; "node0x231523c7db0":f1 -> "node0x231523c7e10";

&#x20; "node0x231523c7e10" \[label="<f0> | 2026-06-05 | <f1> | 2026-06-15 | <f2>"];

&#x20; "node0x231523c7db0":f2 -> "node0x231523ae3c0";

&#x20; "node0x231523ae3c0" \[label="<f0> | 2026-08-10 | <f1> | 2026-08-15 | <f2>"];

&#x20; "node0x231523c7db0":f3 -> "node0x231523aeca0";

&#x20; "node0x231523aeca0" \[label="<f0> | 2026-10-15 | <f1> | 2026-12-10 | <f2>"];

&#x20; "node0x231523abd20":f1 -> "node0x231523abd80";

&#x20; "node0x231523abd80" \[label="<f0> | 2027-03-15 | <f1>"];

&#x20; "node0x231523abd80":f0 -> "node0x231523ab7f0";

&#x20; "node0x231523ab7f0" \[label="<f0> | 2027-01-10 | <f1> | 2027-01-20 | <f2> | 2027-02-14 | <f3> | 2027-02-28 | <f4>"];

&#x20; "node0x231523abd80":f1 -> "node0x231523abc00";

&#x20; "node0x231523abc00" \[label="<f0> | 2027-03-22 | <f1> | 2027-04-12 | <f2> | 2027-05-01 | <f3>"];

&#x20; "node0x231523abd20":f2 -> "node0x231523ad770";

&#x20; "node0x231523ad770" \[label="<f0> | 2027-07-22 | <f1> | 2027-11-15 | <f2>"];

&#x20; "node0x231523ad770":f0 -> "node0x231523ad710";

&#x20; "node0x231523ad710" \[label="<f0> | 2027-06-30 | <f1>"];

&#x20; "node0x231523ad770":f1 -> "node0x231523ae360";

&#x20; "node0x231523ae360" \[label="<f0> | 2027-08-05 | <f1> | 2027-09-18 | <f2> | 2027-09-30 | <f3> | 2027-10-05 | <f4>"];

&#x20; "node0x231523ad770":f2 -> "node0x231523aa3b0";

&#x20; "node0x231523aa3b0" \[label="<f0> | 2027-11-30 | <f1> | 2027-12-01 | <f2> | 2027-12-20 | <f3> | 2028-01-15 | <f4>"];

&#x20; "node0x231523abd20":f3 -> "node0x231523ae270";

&#x20; "node0x231523ae270" \[label="<f0> | 2028-10-25 | <f1> | 2029-01-01 | <f2>"];

&#x20; "node0x231523ae270":f0 -> "node0x231523abde0";

&#x20; "node0x231523abde0" \[label="<f0> | 2028-02-14 | <f1> | 2028-05-10 | <f2> | 2028-06-20 | <f3>"];

&#x20; "node0x231523ae270":f1 -> "node0x231523ad7d0";

&#x20; "node0x231523ad7d0" \[label="<f0> | 2028-11-30 | <f1> | 2028-12-10 | <f2> | 2028-12-10 | <f3>"];

&#x20; "node0x231523ae270":f2 -> "node0x231523ae210";

&#x20; "node0x231523ae210" \[label="<f0> | 2029-05-15 | <f1> | 2030-01-01 | <f2> | 2030-01-01 | <f3> | 2030-01-01 | <f4>"];

}









##### **ÁRBOL B+**



digraph G {

&#x20; rankdir=TB;

&#x20; nodesep=0.5;

&#x20; ranksep=1.0;

&#x20; node \[shape=record, style=filled, fillcolor=lightblue];

&#x20; label="Estructura Árbol B+ - Categorías";

&#x20; "node0x231523ad950" \[label="<f0> | Lacteos | <f1>"];

&#x20; "node0x231523ad950":f0 -> "node0x231523a9e00";

&#x20; "node0x231523ad950":f1 -> "node0x231523ad8a0";

&#x20; "node0x231523a9e00" \[label="<f0> | Botanas | <f1> | Desayuno | <f2> | Galletas | <f3>"];

&#x20; "node0x231523a9e00":f0 -> "node0x231523a1df0";

&#x20; "node0x231523a9e00":f1 -> "node0x231523a1ba0";

&#x20; "node0x231523a9e00":f2 -> "node0x231523c71d0";

&#x20; "node0x231523a9e00":f3 -> "node0x231523aba40";

&#x20; "node0x231523ad8a0" \[label="<f0> | Panaderia | <f1>"];

&#x20; "node0x231523ad8a0":f0 -> "node0x231523c7f60";

&#x20; "node0x231523ad8a0":f1 -> "node0x231523acec0";

&#x20; "node0x231523a1df0" \[label="<f0> | 14524 | <f1> | Abarrotes | <f2> | Bebidas | <f3>"];

&#x20; "node0x231523a1df0" -> "node0x231523a1ba0" \[style=dashed, color=red, constraint=false, label="next"];

&#x20; "node0x231523a1ba0" \[label="<f0> | Botanas | <f1> | Congelados | <f2>"];

&#x20; "node0x231523a1ba0" -> "node0x231523c71d0" \[style=dashed, color=red, constraint=false, label="next"];

&#x20; "node0x231523c71d0" \[label="<f0> | Desayuno | <f1> | Dulces | <f2> | Enlatados | <f3>"];

&#x20; "node0x231523c71d0" -> "node0x231523aba40" \[style=dashed, color=red, constraint=false, label="next"];

&#x20; "node0x231523aba40" \[label="<f0> | Galletas | <f1> | Granos | <f2> | Higiene | <f3>"];

&#x20; "node0x231523aba40" -> "node0x231523c7f60" \[style=dashed, color=red, constraint=false, label="next"];

&#x20; "node0x231523c7f60" \[label="<f0> | Lacteos | <f1> | Limpieza | <f2>"];

&#x20; "node0x231523c7f60" -> "node0x231523acec0" \[style=dashed, color=red, constraint=false, label="next"];

&#x20; "node0x231523acec0" \[label="<f0> | Panaderia | <f1> | Pastas | <f2>"];

&#x20; { rank=same; "node0x231523a1df0"; "node0x231523a1ba0"; "node0x231523c71d0"; "node0x231523aba40"; "node0x231523c7f60"; "node0x231523acec0"; }

}



